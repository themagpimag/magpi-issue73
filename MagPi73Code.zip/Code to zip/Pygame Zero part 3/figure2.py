def makeTiles():
    global tileList
    xoffset = 251
    yoffset = 151
    x = y = c = 0
    while y < 4:
        while x < 4:
            if(c < 15):
                tileList.append(Actor("img"+str(c), pos = (xoffset+(x*100),yoffset+(y*100))))
            c += 1
            x += 1
        x = 0
        y += 1
