import pgzrun
WIDTH = 800
HEIGHT = 600
gameStatus = 0

def draw(): # Pygame Zero draw function
    pass

def update(): # Pygame Zero update function
    pass

def on_mouse_down(pos):
    pass

pgzrun.go()
