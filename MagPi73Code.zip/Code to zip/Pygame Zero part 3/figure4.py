def moveTile(tile):
    borderRight = 551
    rValue = False
    if(tile.x < borderRight): # can we go right?
        tile.x += 1
        if(not checkCollide(tile)): rValue = "right", 100, 0
        tile.x -= 1
   
    return rValue

def checkCollide(tile):
    for t in range(15):
        if tile.colliderect(tileList[t]) and tile != tileList[t]: return True
    return False
