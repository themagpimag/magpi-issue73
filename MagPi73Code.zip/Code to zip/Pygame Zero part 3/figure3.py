def on_mouse_down(pos):
    if (gameStatus == 0):
        doLock()
        for t in range(15):
            if tileList[t].collidepoint(pos):
                m = moveTile(tileList[t])
                if(m != False):
                    animate(tileList[t],on_finished=releaseLock, pos=(tileList[t].x+m[1], tileList[t].y+m[2]))
                    return True
        releaseLock()

def releaseLock():
    global gameStatus
    gameStatus = 0

def doLock():
    global gameStatus
    gameStatus = 1
