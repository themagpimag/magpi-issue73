def update(): # Pygame Zero update function
    if (gameStatus == 0):
        if keyboard.left: findMoveTile("left")
        if keyboard.right: findMoveTile("right")
        if keyboard.up: findMoveTile("up")
        if keyboard.down: findMoveTile("down")

def findMoveTile(moveDirection):
    doLock()
    for t in range(15):
        m = moveTile(tileList[t])
        if(m != False):
            if(m[0] == moveDirection):
                animate(tileList[t],on_finished=releaseLock, pos=(tileList[t].x+m[1], tileList[t].y+m[2]))
                return True
    releaseLock()
    return False
