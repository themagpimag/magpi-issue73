// Here we access the crate we specified in Cargo.toml.
extern crate sensehat;

// The use statements pull some types into scope, to
// save us some typing.
use sensehat::{Colour, SenseHat, SenseHatError};
use std::{thread::sleep, time::Duration};

// We've declared main as returning a Result, which
// means we can use the ? operator to bail out early
// if our code finds any errors at run-time.
fn main() -> Result<(), SenseHatError> {
    let mut hat = SenseHat::new()?;
    let temp = hat.get_temperature_from_humidity()?;
    println!("It's {} in here", temp);
    // Clear the screen
    hat.clear()?;
    // Instructions for the user
    println!("Shake me!");
    loop {
        // Get the G readings from the sensehat
        let accel = hat.get_accel_raw()?;
        // Show them on screen in debug format.
        println!("{:?}", accel);
        // Check if any acceleration value is too high
        if [accel.x, accel.y, accel.z].iter().any(|g| *g > 1.5) {
            // If so, print a warning message!
            hat.text("Earthquake!", Colour::WHITE, Colour::RED)?;
            // Pause on the final character
            sleep(Duration::from_millis(1000));
            // Turn the screen off
            hat.clear()?;
        }
        // Let our CPU rest for a short while to slow down
        // the output.
        sleep(Duration::from_millis(250));
        // Press Control + C to quit this loop!
    }
}
