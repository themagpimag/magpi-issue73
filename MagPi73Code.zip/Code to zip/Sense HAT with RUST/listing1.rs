// Here we access the crate we specified in Cargo.toml.
extern crate sensehat;

// The use statements pull some types into scope, to
// save us some typing.
use sensehat::SenseHat;

// main() gets called when we run our program
fn main() {
    // The variable 'hat' represents our SenseHat. We mark
    // it mutable (otherwise it would be const, or read-only).
    let mut hat = SenseHat::new().unwrap();
    // Get the temperature and unwrap the result.
    let temp = hat.get_temperature_from_humidity().unwrap();
    // Tell everyone how hot it is using the println! macro.
    println!("It's {} in here", temp);
}
